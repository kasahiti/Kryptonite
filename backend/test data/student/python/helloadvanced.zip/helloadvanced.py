def sayHello(name: str):
    return "Hello, " + name
