def SaydfdsfellosD(name:str):
    return "Hello, "+name

def sayHello(name: str):
    return "Hello, " + name
